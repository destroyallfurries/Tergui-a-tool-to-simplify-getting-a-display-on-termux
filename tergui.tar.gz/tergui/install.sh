#!/data/data/com.termux/files/usr/bin/bash
# Installs tergui directly into $PREFIX. Run this from inside Termux, e.g.:
#   bash install.sh
set -euo pipefail

PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Installing tergui into $PREFIX ..."

install -Dm755 "$SRC_DIR/bin/tergui" "$PREFIX/bin/tergui"
install -Dm755 "$SRC_DIR/bin/tergui-x11-alias" "$PREFIX/bin/tergui:x11"
install -Dm755 "$SRC_DIR/bin/tergui-wayland-alias" "$PREFIX/bin/tergui:wayland"

mkdir -p "$PREFIX/share/tergui"
for f in session-x11.sh session-wayland.sh stop.sh status.sh doctor.sh; do
  install -Dm755 "$SRC_DIR/share/tergui/$f" "$PREFIX/share/tergui/$f"
done

echo "Done."
echo "Next: run 'tergui doctor' to see what still needs installing."
