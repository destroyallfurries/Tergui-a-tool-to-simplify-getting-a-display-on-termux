# tergui

A GUI server manager for Termux. `tergui` gives you a one-command way to
spin up a display server so you can run graphical Linux apps (QEMU, GTK/Qt
apps, terminals, etc.) inside Termux.

It ships two modes:

- **`tergui:x11`** — starts a real X11 server bridged to the
  [Termux:X11](https://github.com/termux/termux-x11) companion app, plus a
  lightweight window manager.
- **`tergui:wayland`** — starts a nested [Weston](https://gitlab.freedesktop.org/wayland/weston)
  compositor for Wayland-native apps.

## Why X11 is the foundation

Android has no built-in way for a sandboxed app like Termux to draw
directly onto the screen — that's what the **Termux:X11** app provides: it
receives an X11 protocol stream over a socket and renders it. There is no
equivalent official Wayland bridge for Android, so `tergui:wayland` runs
Weston nested *inside* the X11 session (as an X11 client) rather than
talking to Android directly. Practically:

- Use `tergui:x11` for anything X11-based — this includes **QEMU**, most
  emulators, and the large majority of Linux GUI software.
- Use `tergui:wayland` only for apps that specifically require a Wayland
  compositor; it will auto-start the X11 session underneath it if one
  isn't already running.

## Install

Requirements (install once):

```sh
pkg install x11-repo
pkg install termux-x11-nightly fluxbox weston pulseaudio
```

Also install the **Termux:X11** app on your device (F-Droid or the
[GitHub releases page](https://github.com/termux/termux-x11/releases)) —
this is the piece that actually renders the display; it's a separate APK,
not a Termux package.

Then, from this project's directory:

```sh
bash install.sh
```

This installs `tergui`, `tergui:x11`, and `tergui:wayland` into
`$PREFIX/bin`. Run `tergui doctor` afterward to confirm everything's in
place.

### Building a real .deb instead

If you maintain a Termux package repo, `build.sh.packages-template` is
written in the `TERMUX_PKG_*` format used by
[termux-packages](https://github.com/termux/termux-packages) — drop this
whole folder in as `packages/tergui/`, rename the template file to
`build.sh`, and build with `./build-package.sh tergui`.

## Usage

```sh
tergui doctor              # check what's installed
tergui:x11                 # start the X11 server + window manager
tergui:wayland             # start a nested Wayland compositor

# Launch an app directly in one shot:
tergui:x11 qemu-system-x86_64 -m 2048 -hda disk.img -display gtk

tergui status               # see what's running
tergui stop                 # tear everything down
```

After `tergui:x11` starts, open the **Termux:X11** app on your device —
that's the window the display actually appears in.

### QEMU tips

- Use `-display gtk` or `-display sdl` (not `-nographic`).
- For better performance, look into `-enable-kvm` (if your device/kernel
  supports it) and `-vga virtio` with virgl for GPU-accelerated graphics.
- Audio: `pulseaudio` is started automatically by `tergui:x11` if
  installed; pass `-audiodev pa,id=snd0` to QEMU.

## Layout

```
bin/tergui                     # main dispatcher (x11 / wayland / stop / status / doctor)
bin/tergui-x11-alias           # installed as `tergui:x11`
bin/tergui-wayland-alias       # installed as `tergui:wayland`
share/tergui/session-x11.sh    # X11 session logic
share/tergui/session-wayland.sh# Wayland session logic
share/tergui/stop.sh
share/tergui/status.sh
share/tergui/doctor.sh
install.sh                     # direct installer
build.sh.packages-template     # termux-packages build.sh template
```

## Known limitations

- No native Wayland-to-Android bridge exists yet, so `tergui:wayland` is
  always nested on X11 today.
- GPU acceleration depends heavily on your device's GPU drivers and which
  QEMU display/GL backend you use — expect to tune this per device.
- This manages *processes*, not persistence across reboots. For that,
  wire the scripts into `termux-services` (`sv-enable`) yourself, or ask
  and I'll add service files.
