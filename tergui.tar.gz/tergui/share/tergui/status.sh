#!/data/data/com.termux/files/usr/bin/bash
# tergui: show session status
RUN="$HOME/.tergui"
echo "== tergui status =="
for name in x11 wayland; do
  f="$RUN/$name.pids"
  if [ -s "$f" ] 2>/dev/null; then
    alive=""
    while read -r pid; do
      [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && alive="$alive $pid"
    done < "$f"
    if [ -n "$alive" ]; then
      echo "$name: running (pids:$alive)"
    else
      echo "$name: stopped (stale pidfile)"
    fi
  else
    echo "$name: stopped"
  fi
done
