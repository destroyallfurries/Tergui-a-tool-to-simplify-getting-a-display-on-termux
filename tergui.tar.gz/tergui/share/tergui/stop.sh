#!/data/data/com.termux/files/usr/bin/bash
# tergui: stop all sessions
set -uo pipefail

RUN="$HOME/.tergui"
for f in "$RUN"/x11.pids "$RUN"/wayland.pids; do
  [ -f "$f" ] || continue
  while read -r pid; do
    [ -n "$pid" ] && kill "$pid" 2>/dev/null || true
  done < "$f"
  : > "$f"
done

pkill -f 'termux-x11' 2>/dev/null || true
pkill -f 'weston --backend=x11-backend.so' 2>/dev/null || true

echo "tergui: stopped"
