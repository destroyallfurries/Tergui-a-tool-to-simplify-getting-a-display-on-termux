#!/data/data/com.termux/files/usr/bin/bash
# tergui: X11 session — bridges to the Termux:X11 companion app
set -euo pipefail

RUN="$HOME/.tergui"
mkdir -p "$RUN"
PIDFILE="$RUN/x11.pids"
LOG="$RUN/x11.log"
DISPLAY_NUM=":${TERGUI_DISPLAY:-0}"
: > "$PIDFILE"

if ! command -v termux-x11 >/dev/null 2>&1; then
  echo "tergui: 'termux-x11' binary not found." >&2
  echo "  Install with: pkg install x11-repo && pkg install termux-x11-nightly" >&2
  echo "  Also install the Termux:X11 companion APK on your device." >&2
  exit 1
fi

echo "tergui: starting X11 server on display $DISPLAY_NUM"
termux-x11 "$DISPLAY_NUM" >>"$LOG" 2>&1 &
echo $! >> "$PIDFILE"
sleep 1

export DISPLAY="$DISPLAY_NUM"

if command -v pulseaudio >/dev/null 2>&1; then
  pulseaudio --start --exit-idle-time=-1 >>"$LOG" 2>&1 || true
fi

if command -v fluxbox >/dev/null 2>&1; then
  fluxbox >>"$LOG" 2>&1 &
  echo $! >> "$PIDFILE"
elif command -v openbox >/dev/null 2>&1; then
  openbox >>"$LOG" 2>&1 &
  echo $! >> "$PIDFILE"
else
  echo "tergui: no window manager found — install one for decorations/taskbar:"
  echo "  pkg install fluxbox   (lightweight)"
fi

cat <<EOF

tergui: X11 ready on DISPLAY=$DISPLAY_NUM
  1. Open the Termux:X11 app on this device (F-Droid or GitHub releases)
  2. Point any X11 app here, e.g.:
       DISPLAY=$DISPLAY_NUM qemu-system-x86_64 -display gtk -m 2048 -hda disk.img
  3. Stop everything with: tergui stop

EOF

if [ "$#" -gt 0 ]; then
  echo "tergui: launching: $*"
  exec "$@"
fi
