#!/data/data/com.termux/files/usr/bin/bash
# tergui: dependency checker
check() {
  if command -v "$1" >/dev/null 2>&1; then
    echo "  [x] $1"
  else
    echo "  [ ] $1   -> $2"
  fi
}

echo "tergui doctor"
echo ""
echo "X11 stack (required for GUI apps incl. QEMU):"
check termux-x11 "pkg install x11-repo && pkg install termux-x11-nightly (+ Termux:X11 APK)"
check fluxbox    "pkg install fluxbox"
check pulseaudio "pkg install pulseaudio"

echo ""
echo "Wayland stack (nests on X11):"
check weston "pkg install weston"

echo ""
echo "QEMU (optional, common use case):"
check qemu-system-x86_64 "pkg install qemu-system-x86-64-headless (or the -full variant)"
check qemu-system-aarch64 "pkg install qemu-system-aarch64-headless"

echo ""
echo "Also confirm the Termux:X11 companion app is installed on your device"
echo "(F-Droid, or https://github.com/termux/termux-x11/releases)."
