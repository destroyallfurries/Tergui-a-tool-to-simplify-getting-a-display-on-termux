#!/data/data/com.termux/files/usr/bin/bash
# tergui: Wayland session — runs a nested Weston compositor.
# Android has no native Wayland display path, so this nests Weston as an
# X11 client inside the tergui X11 session (auto-started if needed).
set -euo pipefail

RUN="$HOME/.tergui"
mkdir -p "$RUN"
SHARE_DIR="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$RUN/wayland.pids"
LOG="$RUN/wayland.log"
: > "$PIDFILE"

if ! command -v weston >/dev/null 2>&1; then
  echo "tergui: 'weston' not found." >&2
  echo "  Install with: pkg install weston" >&2
  exit 1
fi

if [ -z "${DISPLAY:-}" ]; then
  echo "tergui: no X11 DISPLAY detected — starting one first (Wayland nests on X11)"
  "$SHARE_DIR/session-x11.sh" &
  echo $! >> "$PIDFILE"
  sleep 2
  export DISPLAY=":${TERGUI_DISPLAY:-0}"
fi

WAYLAND_SOCKET="${TERGUI_WAYLAND_DISPLAY:-wayland-tergui}"
echo "tergui: starting Weston (Wayland) nested on DISPLAY=$DISPLAY as $WAYLAND_SOCKET"
weston --backend=x11-backend.so --width=1280 --height=720 \
  --socket="$WAYLAND_SOCKET" >>"$LOG" 2>&1 &
echo $! >> "$PIDFILE"
sleep 1

export WAYLAND_DISPLAY="$WAYLAND_SOCKET"

cat <<EOF

tergui: Wayland compositor ready (WAYLAND_DISPLAY=$WAYLAND_SOCKET), shown in a window on the X11 session
  Run Wayland-native apps, e.g.:
    WAYLAND_DISPLAY=$WAYLAND_SOCKET weston-terminal
  Note: QEMU and most GUI apps are X11-only — use 'tergui x11' for those instead.
  Stop everything with: tergui stop

EOF

if [ "$#" -gt 0 ]; then
  echo "tergui: launching: $*"
  exec "$@"
fi
